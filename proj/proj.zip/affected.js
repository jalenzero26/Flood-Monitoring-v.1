// Fetch your data first
async function loadAffectedData() {
    try {
        const response = await fetch('data.json');
        const db = await response.json();
        const container = document.getElementById('affected-list-body');
        container.innerHTML = '';

        // Extract barangays from the nested structure
        const barangays = Object.keys(db.barangay_historical_data)
            .filter(b => b !== "Default")
            .map(b => ({
                name: b,
                status: db.barangay_historical_data[b].status || "Normal",
                score: db.barangay_historical_data[b].current_impact_score || 0
            }))
            .sort((a, b) => b.score - a.score); // Sort by highest score

        // Render rows
        barangays.forEach(item => {
            const row = document.createElement('div');
            row.className = `affected-row status-${item.status.toLowerCase()}`;
            row.innerHTML = `
                <span>${item.name}</span>
                <span>${item.status}</span>
                <span>${item.score}</span>
            `;
            container.appendChild(row);
        });
    } catch (err) {
        console.error("Error loading data:", err);
    }
}

// Initialize on load
document.addEventListener('DOMContentLoaded', loadAffectedData);