// 1. Global State
let masterDatabase = null;
const barangayList = ["Biñan", "Bungahan", "Canlalay", "Casile", "De La Paz", "Ganado", "Langkiwa", "Loma", "Malaban", "Malamig", "Mampalasan", "Platero", "Poblacion", "San Antonio", "San Francisco", "San Jose", "San Vicente", "Santo Domingo", "Santo Niño", "Santo Tomas", "Soro-Soro", "Timbao", "Tubigan", "Zapote"];

// --- Initialize Chart Object ---
const ctx = document.getElementById('floodChart').getContext('2d');
const floodChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: [],
        datasets: [{
            label: 'Water Depth (cm)',
            data: [],
            borderColor: '#0038a8',
            tension: 0.3,
            fill: true,
            backgroundColor: 'rgba(0, 56, 168, 0.1)'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { title: { display: true, text: 'Select a Barangay' } }
    }
});


// 2. Fetch Data
fetch('data.json')
    .then(res => res.json())
    .then(data => { masterDatabase = data; updateAnalyticsDashboard(); })
    .catch(err => console.error("Database Error:", err));

// 3. Logic to retrieve data
function generateChartData(barangay, interval, year, month, date) {
    if (!masterDatabase || !masterDatabase.barangay_historical_data) return { error: true };
    
    const dbSource = masterDatabase.barangay_historical_data[barangay] || masterDatabase.barangay_historical_data["Default"];
    
    if (!dbSource || !dbSource[year] || !dbSource[year][interval]) return { error: true };
    
    const node = dbSource[year][interval];
    
    // Added safety check for empty data
    if (!node.depths || node.depths.length === 0) return { error: true }; 
    
    return {
        error: false,
        labels: node.labels,
        data: node.depths,
        titleText: `${barangay} - ${interval.toUpperCase()} (${year})`,
        peak: Math.max(...node.depths),
        avg: Math.round(node.depths.reduce((a, b) => a + b, 0) / node.depths.length),
        simulatedHours: Math.round((Math.max(...node.depths) / 250) * 48)
    };
}

// 4. Update Function
function updateAnalyticsDashboard() {
    if (!masterDatabase) return;

    // Normalize name
    const raw = document.getElementById('barangaySearch').value.trim();
    const name = raw.length > 0 ? raw.charAt(0).toUpperCase() + raw.slice(1).toLowerCase() : "Default";
    
    // Get all filter values
    const interval = document.getElementById('intervalSelect').value;
    const year = document.getElementById('yearSelect').value;
    const month = document.getElementById('monthSelect').value;
    const date = document.getElementById('daySelect').value;

    // Toggle filter visibility
    document.getElementById('yearFilterGroup').style.display = (interval === 'yearly') ? 'none' : 'block';
    document.getElementById('monthFilterGroup').style.display = (['hourly', 'daily', 'weekly'].includes(interval)) ? 'block' : 'none';
    document.getElementById('dayFilterGroup').style.display = (interval === 'hourly') ? 'block' : 'none';

    const render = generateChartData(name, interval, year, month, date);

    if (render.error) {
        document.getElementById('errorOverlay').style.display = 'flex';
        floodChart.data.labels = [];
        floodChart.data.datasets[0].data = [];
    } else {
        document.getElementById('errorOverlay').style.display = 'none';
        floodChart.data.labels = render.labels;
        floodChart.data.datasets[0].data = render.data;
        document.getElementById('metricPeak').innerText = `${render.peak} cm`;
        document.getElementById('metricAvg').innerText = `${render.avg} cm`;
        document.getElementById('metricHours').innerText = `${render.simulatedHours} hrs`;
    }
    floodChart.update();
}

// 5. Suggestion Logic
const searchInput = document.getElementById('barangaySearch');
const suggestionsBox = document.getElementById('suggestions');

searchInput.addEventListener('input', () => {
    const val = searchInput.value.toLowerCase();
    suggestionsBox.innerHTML = '';
    if (!val) { suggestionsBox.style.display = 'none'; return; }
    
    const matches = barangayList.filter(b => b.toLowerCase().includes(val));
    if (matches.length > 0) {
        suggestionsBox.style.display = 'block';
        matches.forEach(m => {
            const div = document.createElement('div');
            div.className = 'suggestion-item';
            div.textContent = m;
            div.onclick = () => { searchInput.value = m; suggestionsBox.style.display = 'none'; updateAnalyticsDashboard(); };
            suggestionsBox.appendChild(div);
        });
    }
});

// 6. Listeners
['intervalSelect', 'yearSelect', 'monthSelect', 'daySelect', 'barangaySearch'].forEach(id => {
    document.getElementById(id).addEventListener('change', updateAnalyticsDashboard);
});